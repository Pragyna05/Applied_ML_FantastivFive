Dataset can be downloaded from Kaggle MillionSongDataset Challenge

Algo1 Popularity based
cd /Algo1_popularity
sudo python popu.py

Algo2 Collaborative Filtering
cd /Algo2_CollaborativeFiltering
sudo python MSD_subm_rec.py min_user_id max_user_id outputfile

Algo3 SVD model
cd /Algo3_Latent_factor
sudo python svd_validonly.py

Algo4 KNN
cd /Algo4_knn
sudo python kNN.py

